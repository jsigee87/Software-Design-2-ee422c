the test cases are not here
they are moved to assignment3/grading_and_solution/test_cases
they will be automatically moved to appropriate place when the grading is being prepared
